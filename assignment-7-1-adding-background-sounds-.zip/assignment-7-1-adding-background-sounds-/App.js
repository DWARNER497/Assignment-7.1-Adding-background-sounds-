import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, Button, SafeAreaView } from 'react-native';
import { Audio } from 'expo-av';

export default function App() {
  const [sound, setSound] = useState(null);       // For short sound effects
  const [bgSound, setBgSound] = useState(null);   // For background looping sound

  /**
   *  playSoundEffect
   * Plays a short sound effect (like a button-triggered sound)
   */
  async function playSoundEffect(soundFile) {
    try {
      if (sound !== null) {
        await sound.unloadAsync();
      }
      const { sound: newSound } = await Audio.Sound.createAsync(soundFile);
      setSound(newSound);
      await newSound.playAsync();
    } catch (error) {
      console.error('Error playing sound effect:', error);
    }
  }

  /**
   * playBackgroundSound
   * Loads and plays looping ambient sound for the app's mood
   */
  async function playBackgroundSound() {
    try {
      const { sound: background } = await Audio.Sound.createAsync(
        require('./assets/Minecraft.mp3'),
        {
          shouldPlay: true,
          isLooping: true,
          volume: 0.9,
        }
      );
      setBgSound(background);
    } catch (error) {
      console.error('Error loading background sound:', error);
    }
  }

  /**
   * 🧹 useEffect: Cleanup on unmount
   * Unloads both short and background sounds to free memory
   */
  useEffect(() => {
    playBackgroundSound();

    return () => {
      if (sound) sound.unloadAsync();
      if (bgSound) bgSound.unloadAsync();
    };
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}> Sound Experience</Text>

      <View style={styles.buttonContainer}>
        <Button
          title="🐔 Chicken Jockey"
          onPress={() =>
            playSoundEffect(require('./assets/chicken-jockey.mp3'))
          }
        />
      </View>

      <View style={styles.buttonContainer}>
        <Button
          title="I am STEVE"
          onPress={() =>
            playSoundEffect(require('./assets/i-am-steve.mp3'))
          }
        />
      </View>

      <Text style={styles.footer}>
        🎶 Ambient background sound is playing to create immersive experience.
      </Text>
    </SafeAreaView>
  );
}

// 🎨 Styling for layout and readability
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f2f8ff',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 30,
    textAlign: 'center',
  },
  buttonContainer: {
    width: '100%',
    marginBottom: 20,
  },
  footer: {
    marginTop: 40,
    textAlign: 'center',
    fontStyle: 'italic',
    color: '#444',
  },
});
